package tests;

import com.codeborne.selenide.Configuration;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;
import pages.MainPage;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.open;

public class MainPageTest extends BaseTest {
    MainPage mainPage = new MainPage();

    @BeforeSuite
    public void setUp() {
        Configuration.browser = "chrome";
        Configuration.baseUrl = "https://qauto2.forstudy.space";

    }

    @Test
    public void ForgotPassBtn() {


        mainPage.open()
                .clickSignInBtn()
                .LoginFrom()
                .clickForPassBtn()
                .setEmail("nnnnnn@gmail.com")
                .clickSendBtn();
    }

    @Test
    public void LogIn() {


        mainPage.open()
                .clickSignInBtn()
                .LoginFrom()
                .setEmail("dtlkbnl@gmail.com")
                .setPass("Qw1234567890")
                .ClickLogInBtn()
                .CheckMyProfile("My Profile");


    }

    @Test
    public void Register() {


        mainPage.open();
        mainPage.clickSignInBtn();
        mainPage.LoginFrom();
        mainPage.RegBtn();
        mainPage.RegForm();
        mainPage.NameField("Nnnnn");
        mainPage.LastnameField("Mmmmm");
        mainPage.setEmailField("Nnnnn@gmail.com");
        mainPage.setPassField("Qw1234567890");
        mainPage.reenterPass("Qw1234567890");
        mainPage.ClickRegisterBtn();
    }

    @Test
    public void AddCar() {


        mainPage.open()
                .clickSignInBtn()
                .LoginFrom()
                .setEmail("dtlkbnl@gmail.com")
                .setPass("Qw1234567890")
                .ClickLogInBtn()
                .AddCarBtn()
                .AddCarForm()
                .AddCarMilleage("88888")
                .AddBtn();

    }
}