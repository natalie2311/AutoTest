package pages;

import com.codeborne.selenide.Conditional;
import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;
import org.example.Main;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.w3c.dom.html.HTMLInputElement;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.open;

public class MainPage {
    public SelenideElement SignInBtn = $("button.btn.btn-outline-white.header_signin");
    public SelenideElement Loginform = $("app-signin-modal > div.modal-header > h4");
    public SelenideElement ForPassBtn = $("button.btn.btn-link");
    private SelenideElement emailField = $("#signinEmail.form-control.ng-untouched.ng-pristine.ng-invalid");
    private SelenideElement clickSendBtn = $("app-forgot-password-modal button.btn.btn-primary");
    private SelenideElement passField = $("#signinPassword.form-control.ng-untouched.ng-pristine.ng-invalid");
    private SelenideElement ClickLogInBtn= $(By.cssSelector("app-signin-modal button.btn.btn-primary"));
    private SelenideElement RegBtn= $(By.cssSelector("body > ngb-modal-window > div > div > app-signin-modal > div.modal-footer.d-flex.justify-content-between > button.btn.btn-link"));
    private SelenideElement RegForm= $(By.cssSelector("h4.modal-title"));
    private SelenideElement NameField= $(By.cssSelector("#signupName"));
    private SelenideElement LastnameField = $(By.cssSelector("#signupLastName"));
    private SelenideElement reenterPass = $(By.cssSelector("#signupRepeatPassword"));
    private SelenideElement setEmailField= $(By.cssSelector("#signupEmail"));
    private SelenideElement setPassField= $(By.cssSelector("#signupPassword"));
    private SelenideElement ClickRegisterBtn = $(By.cssSelector("ngb-modal-window > div > div > app-signup-modal > div.modal-footer > button"));


    public MainPage open() {
        Selenide.open("", "", "guest", "welcome2qauto");
        return this;
    }

    public MainPage clickSignInBtn() {
        SignInBtn.click();
        return this;
    }

    public MainPage LoginFrom() {
        Loginform.shouldHave(text("Log in"));
        return this;
    }

    public MainPage clickForPassBtn() {
        ForPassBtn.click();
        return this;
    }

    public MainPage setEmail(String email) {
        emailField.sendKeys(email);
        return this;
    }

    public MainPage clickSendBtn() {
        clickSendBtn.shouldHave(visible).click();
        return this;
    }

    public MainPage setPass(String pass) {
        passField.sendKeys(pass);
        return this;
    }

    public Panel_Garage ClickLogInBtn() {
        ClickLogInBtn.shouldHave(visible).click();
        return new Panel_Garage();
    }
    public MainPage RegBtn(){
        RegBtn.shouldHave(visible).click();
        return this;

    }public MainPage RegForm() {
        RegForm.shouldHave(text("Registration"));
        return this;
    }
    public MainPage NameField(String Name) {
        NameField.sendKeys(Name);
        return this;
    }

    public MainPage LastnameField(String Lastname) {
        LastnameField.sendKeys(Lastname);
        return this;
    }

    public MainPage reenterPass(String ReenterPass) {
        reenterPass.sendKeys(ReenterPass);
        return this;
    }

    public MainPage setEmailField(String Email) {
        setEmailField.sendKeys(Email);
        return this;
    }
    public MainPage setPassField(String Password) {
        setPassField.sendKeys(Password);
        return this;
    }

    public MainPage ClickRegisterBtn() {
        ClickRegisterBtn.shouldHave(visible).click();
        return this;
    }
}
