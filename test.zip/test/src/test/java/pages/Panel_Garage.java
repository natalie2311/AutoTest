package pages;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.Conditional;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;

public class Panel_Garage {
    private SelenideElement MyProfile = $(By.cssSelector("#userNavDropdown"));
    private SelenideElement AddCarBtn = $(By.cssSelector("body > app-root > app-global-layout > div > div > div > app-panel-layout > div > div > div > div.col-lg-9.main-wrapper > div > app-garage > div > div.panel-page_heading.d-flex.justify-content-between > button"));
    private SelenideElement AddCarForm = $(By.cssSelector("body > ngb-modal-window > div > div > app-add-car-modal > div.modal-header > h4"));
    private SelenideElement AddCarMilleage = $(By.cssSelector("#addCarMileage"));
    private SelenideElement AddBtn = $(By.cssSelector("body > ngb-modal-window > div > div > app-add-car-modal > div.modal-footer.d-flex.justify-content-end > button.btn.btn-primary"));

    public Panel_Garage CheckMyProfile(String profileText) {
    MyProfile.shouldHave(Condition.text(profileText));
        return this;

    }

    public Panel_Garage AddCarBtn() {
        AddCarBtn.shouldHave(visible).click();
        return this;
    }

    public Panel_Garage AddCarForm() {
        AddCarForm.shouldHave(text("Add a car"));
        return this;
    }

    public Panel_Garage AddCarMilleage(String Mileage) {
        AddCarMilleage.sendKeys(Mileage);
        return this;
    }

    public Panel_Garage AddBtn() {
        AddBtn.shouldHave(visible).click();
        return this;
    }
}
