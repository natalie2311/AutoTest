import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;
public class SeleniumTest {
@Test
public void openAuto(){
    WebDriver driver= new ChromeDriver();

    driver.get("https://guest:welcome2qauto@qauto2.forstudy.space");

    WebElement signInBtn= driver.findElement(By.cssSelector("button.btn.btn-outline-white.header_signin"));

    signInBtn.click();

    WebElement loginform= driver.findElement(By.cssSelector("app-signin-modal > div.modal-header > h4"));

    Assert.assertEquals(loginform.getText(),"Log in");

    WebElement ForPassBtn= driver.findElement(By.cssSelector("button.btn.btn-link"));

    ForPassBtn.click();
}
}
